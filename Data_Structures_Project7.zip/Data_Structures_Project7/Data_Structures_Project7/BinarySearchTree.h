// Ray Alligood
// COP2535.0M1 Data Stuctures
// Project 7
// This program creates a simple binary tree with 5 numbers and does a search on an entered value

#ifndef BINARYSEARCHTREE_H
#define BINARYSEARCHTREE_H

#include <iostream>
#include <vector>

using namespace std;

class BinarySearchTree										// Class
{
private:
	class BtreeNode											// Class for the tree nodes
	{
		friend class BinarySearchTree;						// Make class a friend class of BinarySearchTree
		double value;										// Variable
		BtreeNode *left;									// Pointer to a BtreeNode
		BtreeNode *right;									// Pointer to a BtreeNode
		BtreeNode(double value1, BtreeNode *left1 = NULL,	// Default constructor
							  BtreeNode *right1 = NULL)
		{
			value = value1;									// Assign value
			left = left1;									// Assign pointer
			right = right1;									// Assign pointer
		}													// End constructor
	};														// End BtreeNode class
	BtreeNode *root;										// Pointer as the root to a BtreeNode
	bool searchResult;										// Holds the return value
	bool search(double x, BtreeNode *t);					// A private recursion function
	void inorder(vector<double> & v, BtreeNode *) const;	// A private recursion function
public:
	BinarySearchTree(){ root = NULL; }						// Default constructor
	~BinarySearchTree(){ delete root; }						// Deconstructor
	void insert(double x);									// Member function
	void search(double x);									// Member function
	void inorder(vector<double>& v);						// Member function
	void print(vector<double> usrv, double val);			// Member function
};

#endif
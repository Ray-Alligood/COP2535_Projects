// Ray Alligood
// COP2535.0M1 Data Stuctures
// Project 7
// This program creates a simple binary tree with 5 numbers and does a search on an entered value

#include "BinarySearchTree.h"

void BinarySearchTree::insert(double x)
{
	BtreeNode *p = root;						// Point p to root
	if (!root)									// If there is no tree
	{
		root = new BtreeNode(x);				// Create the root of the tree
		return;									// Return
	}
	else
	{
		while (p != NULL)						// Run through to find the location to create the node
		{
			if (x <= p->value)					// If user value is less than or equal to p->value
			{
				if (p->left == NULL)			// Then check to see if the left is pointing to NULL
				{
					p->left = new BtreeNode(x);	// If it is then create a node
					return;						// then return
				}
				else
					p = p->left;				// Else move down to next node on the left of the tree
			}
			else
			{
				if (p->right == NULL)			// Else x must be greater than user value
				{
					p->right = new BtreeNode(x);// Create a new node
					return;						// Then return
				}
				else
					p = p->right;				// Else mode on down the tree
			}									// End if
		}										// End while
	}											// End else
}												// End function
/***************************************************************************/
void BinarySearchTree::inorder(vector<double> & v)
{
	if (root == NULL)							// If root is NULL, then there is no tree
		return;									// then return
	else
		inorder(v, root);						// Else call function
}
/***************************************************************************/
void BinarySearchTree::inorder(vector<double> & v, BtreeNode * root) const
{
	if (root)									// If there is a node
	{
		inorder(v, root->left);					// go left in tree
		v.push_back(root->value);				// Add to vector
		cout << root->value << " ";				// Go a head and print value
		inorder(v, root->right);				// Then move right
	}
}
/***************************************************************************/
void BinarySearchTree::search(double x)
{
		search(x, root);						// Call a recursion function
}
/***************************************************************************/
bool BinarySearchTree::search(double x, BtreeNode * t)
{
	if (t == NULL) return searchResult = false;		// If there is no node set to false
	if (t->value == x) return searchResult = true;	// If value is the same se to true
	if (t->value > x) return search(x, t->left);	// If value is greater than than user value go left
	else
		return search(x, t->right);					// Go right
}
/***************************************************************************/
void BinarySearchTree::print(vector<double> usrv, double val)
{
	vector<double> inOrder;						// Create an empty vector to be passed
	inOrder.clear();							// Clear anything in the vector
	cout << "Your Values: ";
	for (int i = 0; i < usrv.size(); i++)		// Print the entered values
		cout << usrv.at(i) << " " ;
	cout << endl;
	cout << "Your Values in Order: ";
	inorder(inOrder);							// Call function
	cout << endl;
	cout << "Your search Value: " << val << endl;
	if (searchResult)							// Depending on if reault is true, print the right cout
		cout << "The value " << val << " was located in the tree.\n\n";
	else
		cout << "The value " << val << " was not in the tree.\n\n";
}
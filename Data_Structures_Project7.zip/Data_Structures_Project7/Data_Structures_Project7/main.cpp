// Ray Alligood
// COP2535.0M1 Data Stuctures
// Project 7
// This program creates a simple binary tree with 5 numbers and does a search on an entered value

#include "BinarySearchTree.h"


int main()
{
	BinarySearchTree tree;						// Create an object
	double usrVal;								// Variable to hold user values
	double sVal;								// Valiable to hold user search value
	vector<double> usrVals;						// Vector which only to be past to the print function

	cout << "Please enter 5 numbers" << endl;	// Prompt user to enter 5 numbers
	for (int x = 0; x < 5; x++)					// Loop through
	{
		cout << "Value " << x + 1 << ": ";
		cin >> usrVal;							// Get user input value
		tree.insert(usrVal);					// Call function to insert user value
		usrVals.push_back(usrVal);				// Also insert it into the vector
	}											// End for loop

	cout << "Please enter a value to search.\n";// Prompt user for a number to search for
	cin >> sVal;								// Get user input

	tree.search(sVal);							// Call function to search for value in tree

	system("cls");								// Clear screen befor printing the numbers entered, numbers in order, search value, and if val was found or not
	tree.print(usrVals,sVal);					// Call print function to print everything

	return 0;
}
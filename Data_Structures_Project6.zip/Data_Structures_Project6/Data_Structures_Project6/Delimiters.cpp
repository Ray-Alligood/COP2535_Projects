// Ray Alligood
// COP2535.0M1 Data Stuctures
// Project 6
// This program locates delimiters (), {}, [] and adds them on a stack as nodes and determines if the string was properly delimited.

#include "Delimiters.h"

Delimiters::Delimiters()
{ 
	top = NULL;						// Point top to NULL
	emptystr = false;				// Set bool to false
	loadFile();						// Call member function to load data from file
}
/************************************************************************/
void Delimiters::loadFile()			
{
	string mystr = "";				// Holds the data loaded from file into string
	ifstream dataFile;				// Create a ifstream object
	char ch = ' ';					// Variable to hold the character which are the delimiters (), {}, []

	dataFile.open("string.txt");	// Now try to open file

	if (!dataFile)								// If there is not file	
		cout << "Error opening data file\n";	// print to screen the error
	else
	{
		while (!dataFile.eof())					// While not at end of file
		{
			getline(dataFile, mystr);			// Get the whole line and store it into mystr
			strInFile = mystr;					// Set mystr to strInFile
		}
	}											// End else
		dataFile.close();						// Close the files

// Check for an empty string before moving on	//
		if (mystr.size() == 0)
			emptystr = true;
		else
		{
			for (int i = mystr.size(); i > -1; i--)	// Loop through the string and pull any delimiters on the stack
			{
				ch = mystr[i];						// Set the char in the current index to ch
				if (ch == '{' || ch == '}' || ch == '[' || ch == ']' || ch == '(' || ch == ')')	// If any of these characters match
					push(ch);						// Create a node on the stack
			}										// End for loop
		}

//////////////////////////////////////////////////////////
// This points to the top of the stack and runs through //
// to route the delimiters to the right member function //
// to be counted or substracted							//
//////////////////////////////////////////////////////////
		StackNode *stack = top;							//
		char c;											//
		while (stack)									//
		{												//
			c = stack->ch;								//
														//
			if (c == '(' || c == ')')					//
				parentheses(stack->ch);					//
			else if (c == '[' || c == ']')				//
				brackets(stack->ch);					//
			else if (c == '{' || c == '}')				//
				braces(stack->ch);						//
														//
			stack = stack->next;						//
		}												//
}														//
/********************************************************/
void Delimiters::push(char ch)							// When this member function is called, it will create a new node for stack
{
	top = new StackNode(ch, top);
}
/********************************************************/
void Delimiters::pop(char &s)							// When this member function is called, it will remove/delete the node off the stack
{
	StackNode *temp;									// Create a temp pointer that points to a StackNode
	if (isEmpty())										// If Stack is empty go a head and exit
	{
		cout << "The stack is empty.\n";				// Print that the stack is empty
		exit(1);										// Go a head and call program to exit
	}
	else
	{
		s = top->ch;									// Not sure why the book has the value in the node copied to the passed value. What purpose does this serve?? 
		temp = top;										// Make temp point to what top is pointing to
		top = top->next;								// Top now points to the next pointer
		delete temp;									// Delete temp pointer
	}
}
/********************************************************/
bool Delimiters::isEmpty() const						// This member function speaks for itself
{
	if (!top)
		return true;
	else
		return false;
}
/*******************************************************/
void Delimiters::parentheses(char c)	// If a pair of the same delimiters are paired, then the value will be 0
{
	if (c == '(')						// If c is the left delimiter, then
		parCount++;						// add 1
	else
		parCount--;						// else it is the right delimiter, so minus 1
}
/*******************************************************/
void Delimiters::brackets(char c)		// If a pair of the same delimiters are paired, then the value will be 0
{
	if (c == '[')						// If c is the left delimiter, then
		brackCount++;					// add 1
	else
		brackCount--;					// else it is the right delimiter, so minus 1
}

void Delimiters::braces(char c)			// If a pair of the same delimiters are paired, then the value will be 0
{
	if (c == '{')						// If c is the left delimiter, then
		bracCount++;					// add 1
	else
		bracCount--;					// else it is the right delimiter, so minus 1
}
/****************************************/
void Delimiters::display()
{
	if (emptystr)							// If the file ws empty, then print just that.
		cout << "The file was empty.\n\n";
	else
	{
		StackNode *stack = top;				// Else point back to the top of stack

		cout << "Loaded String:      " << strInFile << endl;	// Print the string in the file
		cout << "Delimiters Found:   ";		// Print the stack of delimiters
		while (stack)						// While there are nodes on the stack
		{
			cout << stack->ch << " ";		// Print them
			stack = stack->next;			// Set stack to the next node on the stack
		}
		cout << "\n\n";
		if (parCount == 0 && bracCount == 0 && brackCount == 0)
			cout << "The string is properly delimited.\n\n";
		else
			cout << "The string is not delimited properly.\n\n";

		cout << "Removing all nodes off the stack...\n";
		stack = top;						// Move back to top of stack to start deleting the nodes off the stack
		while (stack)						// Loop through stack
			pop(stack->ch);					// Call member function to delete the node off the stack
	}
}
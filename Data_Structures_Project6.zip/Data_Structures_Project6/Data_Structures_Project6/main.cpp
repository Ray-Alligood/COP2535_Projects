// Ray Alligood
// COP2535.0M1 Data Stuctures
// Project 6
// This program locates delimiters (), {}, [] and adds them on a stack as nodes and determines if the string was properly delimited.

#include "Delimiters.h"

int main()
{
	Delimiters stack;		// Create an Object

	stack.display();		// Display the delimiters and if the string is properly delimited.
	return 0;
}
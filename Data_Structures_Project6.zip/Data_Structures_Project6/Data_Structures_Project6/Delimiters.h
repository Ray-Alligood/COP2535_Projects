// Ray Alligood
// COP2535.0M1 Data Stuctures
// Project 6
// This program locates delimiters (), {}, [] and adds them on a stack as nodes and determines if the string was properly delimited.

#ifndef DELIMITERS_H
#define DELIMITERS_H

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class Delimiters
{
private: 
	class StackNode					// Class for adding and deleting nodes of a stack
	{
		friend class Delimiters;	// Make StackNode class a friend of Delimiters class
		char ch;					// Holds the character
		StackNode *next;			// Pointer that points to a StackNode
		StackNode(char ch1, StackNode *next1 = NULL)	// Default constructor
		{
			ch = ch1;			// Assign ch1 to ch
			next = next1;		// Make mext1 point to next
		}
	};							// End friend class
	StackNode *top;				// Pointer that points to a StackNode (top of stack)
	int parCount;				// Handles the count, a balanced pair will equal to 0
	int bracCount;				// Handles the count, a balanced pair will equal to 0
	int brackCount;				// Handles the count, a balanced pair will equal to 0
	string strInFile;			// Holds the string from file
	bool emptystr;				// Bool for an empty str
public:
	Delimiters();				// Default constructor
	void loadFile();			// Handles loading the file
	void push(char);			// Adds a node to the stack
	void pop(char &);			// Removes a node off the stack
	bool isEmpty() const;		// Checks to see if the stack is empty
	void parentheses(char);		// Handles parentheses' () '
	void brackets(char);		// Handles brackets' [] '
	void braces(char);			// Handles braces' {} '
	void display();				// For displaying delimiters and if string is properly delimited
};
#endif
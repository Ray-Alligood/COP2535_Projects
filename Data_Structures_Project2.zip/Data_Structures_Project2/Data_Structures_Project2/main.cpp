// Ray Alligood
// COP2535.0M1
// Project 2 [ Benchmarks ]
// This program will produce benchmarks on linear and binary searches using bubble and selection sort.

#include <iostream>
#include <fstream>
#include "Bench.h"

using namespace std;

int main()															
{																	
	Bench myBench;					// Create a Bench object
	int value = 869;				// The value to search

	myBench.bubbleSort();			// Call the bench member function to sort using the bubble sort
	myBench.selectionSort();		// Call the bench member function to sort using the selection sort
	myBench.linearSearch(value);	// Call the bench member function to search the value using linear search
	myBench.binarySearch(value);	// Call the bench member function to search the value using binary search
	myBench.display();				// Call the bench member function to display the results

	return 0;
}
// Ray Alligood
// COP2535.0M1
// Project 2 [ Benchmarks ]
// This program will produce benchmarks on linear and binary searches using bubble and selection sort.

#ifndef BENCH_H
#define BENCH_H

using namespace std;

class Bench														
{																	
private:							
	const static int SIZE = 200;		// Constant int for size of arrays
	int bubbleSortArray[SIZE];			// Array to hold the data from random.txt file
	int bubbleSortExchangeCount;		// Variable to store the exchanges for the bubble sort
	int selectionSortArray[SIZE];		// Array to hold the same data from random.txt file
	int selectionSortExchangeCount;		// Variable to store the exchanges for the selection sort
	int linearCount;					// Variable to store the comparisions using the linear search
	int binaryCount;					// Variable to store the comparisions using the binary search
public:																
	Bench();							// Default Function
	void bubbleSort();					// Function to sort using the bubble sort
	void selectionSort();				// Function to sort using the selection sort
	void linearSearch(int);				// Function to locate a value using the linear search
	void binarySearch(int);				// Function to locate a value using the binary search
	int getExchangeCount(char);			// Function to return the counts for bubble and selection sort
	void display();						// Function to display the results
	void writeData();					// Function to test the accuracy of the program
};																	
#endif
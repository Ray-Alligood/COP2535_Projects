// Ray Alligood
// COP2535.0M1
// Project 2 [ Benchmarks ]
// This program will produce benchmarks on linear and binary searches using bubble and selection sort.

#include <iostream>
#include <iomanip>
#include <fstream>
#include "Bench.h"

Bench::Bench()										
{				
	bubbleSortExchangeCount = 0;										// Initialize the variable
	selectionSortExchangeCount = 0;										// Initialize the variable
	linearCount = 0;													// Initialize the variable
	binaryCount = 0;													// Initialize the variable

	ifstream randomdatafile;											// Create an input file stream object										
	int index = 0;														// Simple index variable
	randomdatafile.open("random.txt");									// Open the file 

	if (!randomdatafile)												// If there was a problem open the file
		cout << "Error opening data file\n";							// Print out an error message
	else																// else
		while (randomdatafile >> bubbleSortArray[index])				// While input object reads a value add that value to the current index
			index++;													// Add 1 to index
	randomdatafile.close();												// When done, close the file
																
	for (int y = 0; y < SIZE; y++)										// Copy the items in the bubbleSortArray into the selectionSortArray
	{
		selectionSortArray[y] = bubbleSortArray[y];						// Copy the values of the bubble sort into the selection array
	}																	// End for loop
}
/***********************************************************************/
void Bench::bubbleSort()
{
	int temp;															// Variable to hold the temp value to be swapped
	bool swap;															// Variable to determine if a swap needs to take place

	do																	// Do while swap is true
	{
		swap = false;													// Set swap to false
		for (int x = 0; x < SIZE - 1; x++)								// For loop to run through the array
		{
			if (bubbleSortArray[x] > bubbleSortArray[x + 1])			// If current index of array is greater than the next, then a swap needs to take place
			{
				temp = bubbleSortArray[x];								// Set current index value to temp
				bubbleSortArray[x] = bubbleSortArray[x + 1];			// Set the value in the index after to the current index
				bubbleSortArray[x + 1] = temp;							// Then set the value in temp into the next array index
				swap = true;											// Set swap to true ro check to see if another swap needs to take place
				bubbleSortExchangeCount += 1;							// Add 1 to the exchange count
				//writeData();											// Do not remove - For testing purposes only
			}															// End if
		}																// End for loop
		//writeData();
	} while (swap);														// End do while loop
	//writeData();														// Do not remove - For testing purposes only
}
/***********************************************************************/
void Bench::selectionSort()
{
	int startScan, minIndex, minValue;									// Variables used for the selection sort

	for (startScan = 0; startScan < (SIZE - 1); startScan++)			// For loop to scan through the array
	{
		minIndex = startScan;											// Set the minIndex to current scan value
		minValue = selectionSortArray[startScan];						// Set the minValue to the current index in the array
		for (int index = startScan + 1; index < SIZE; index++)			// For loop starts at scan value to the end of the array
		{
			if (selectionSortArray[index] < minValue)					// 
			{
				minValue = selectionSortArray[index];					// 
				minIndex = index;										// 
			}															// End if
		}																// End inner for loop
		selectionSortArray[minIndex] = selectionSortArray[startScan];	// 
		selectionSortArray[startScan] = minValue;						// 
		selectionSortExchangeCount++;									// 
		//writeData();
	}	
}														
/***********************************************************************/
void Bench::linearSearch(int value)
{
	int index = 0;														// Variable for the array indexes
	bool found = false;													// Variable if the program finds the value

	while (index < SIZE && !found)										// While index is not at the end of the array and while the value is not found
	{
		if (bubbleSortArray[index] == value)							// If the value is found
		{
			found = true;												// Set found to true and
		}																// End if
		linearCount++;													// add 1 to linear count.
		index++;														// Add 1 to index
	}																	// End while loop
}
/***********************************************************************/
void Bench::binarySearch(int value)
{
	int first = 0,														// Variable for the first index for range
		last = SIZE - 1,												// Variable for the last index for range
		middle;															// Variable for the midle to be compared
	bool found = false;													// Variable flag if the function found the value

	while (!found && first <= last)										// While found is false and fist is less or equal to last
	{
		middle = (first + last) / 2;									// Get the middle index
		if (bubbleSortArray[middle] == value)							// Compare the middle index
		{
			found = true;												// If the found was found
			binaryCount++;												// Add 1 to binary count
		}																// End if
		else if (bubbleSortArray[middle] > value)						// If the middle value is great than the value
		{
			last = middle - 1;											// Set middle - 1 to last
			binaryCount++;												// Add 1 to binary count
		}																// End if
		else
		{
			first = middle + 1;											// Else Set middle + 1 to first
			binaryCount++;												// Add 1 to binary count
		}																// End Else
	}																	// End While
}
/***********************************************************************/
int Bench::getExchangeCount(char sort)							
{
	if (sort == 'B')													// If value passed from main is B 	
		return bubbleSortExchangeCount;									// then return bubble count
	else if (sort == 'S')												// If value passed from main is S
		return selectionSortExchangeCount;								// then return selection count
}
/***********************************************************************/
void Bench::display()													// Statements to print the results
{
	cout << "Bubble Sort Exchange Count: " << setw(10) << getExchangeCount('B') << endl;
	cout << "Selection Sort Exchange Count: " << setw(7) << getExchangeCount('S') << endl;
	cout << "Linear Search Comparison Count: " << setw(6) << linearCount << endl;
	cout << "Binary Search Comparison Count: " << setw(6) << binaryCount << endl;
	cout << "\n\n";
}
/******************************************************************************************/
// THE FUNCTION BELOW IS JUST A TEST FUNCTION FOR ME TO CHECK THE ACCURACY OF THE PROGRAM //
/******************************************************************************************/
void Bench::writeData()
{
	ofstream outfile;

	outfile.open("bubbleSortTest.txt", ios::out | ios::app);
	/*
	for (int x = 0; x < SIZE; x++)
	{
		outfile << setw(4) << x;
	}
	outfile << "\n\n";
	for (int x = 0; x < SIZE; x++)
	{
		outfile << setw(4) << bubbleSortArray[x];
	}
	*/
	
	outfile << "pass" << left << setw(7) << bubbleSortExchangeCount << "  ";
	for (int x = 0; x < SIZE; x++)
	{
		outfile << setw(5) << bubbleSortArray[x];
	}
	outfile << "\n";
	
	/*
	outfile << "pass" << left << setw(3) << selectionSortExchangeCount << "  ";
	for (int x = 0; x < SIZE; x++)
	{
		outfile << setw(5) << selectionSortArray[x];
	}
	
	outfile << "\n";
	*/

	outfile.close();
}
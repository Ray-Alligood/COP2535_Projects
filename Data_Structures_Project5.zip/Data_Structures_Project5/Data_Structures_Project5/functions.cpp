#include "functions.h"
#include "Student.h"

int menu()																// Handles showing the menu
{
	int selection = 0;
	cout << "\tStudent Register Manager Menu\n";
	cout << "---------------------------------------------\n";
	cout << "(1)     ADD -student at the begining of list.\n";
	cout << "(2)     ADD -student at the end of the list.\n";
	cout << "(3)  REMOVE -student at the begining of the list.\n";
	cout << "(4)  REMOVE -student at the end of the list.\n";
	cout << "(5)  REMOVE -student by name.\n";
	cout << "(6) DISPLAY -the list of students.\n";
	cout << "(7)    EXIT -to exit the program.\n";
	cout << "\nEnter a number 1 - 7 from the menu.\n";
	cin >> selection;
	return selection;
}
/***********************************************************************/
string getCase(int caseNum)												// Nothing really special here, just blocks that are used more than once
{
	string name;
	if (caseNum == 1 || caseNum == 2)
	{
		system("cls");
		cin.sync();
		cin.clear();
		cout << "Please enter a name to add. ";
		getline(cin,name);
	}
	else if (caseNum == 5)
	{
		system("cls");
		cin.sync();
		cin.clear();
		cout << "Please enter a name to remove.";
		getline(cin, name);
	}
	else if (caseNum == -1)
	{
		system("cls");
		cin.sync();
		cin.clear();
		cout << "ERROR - Invalid input.\n\n" << endl;
		system("pause");
	}
	return name;
}
// Ray Alligood
// COP2535.0M1 Data Stuctures
// Project 5
// This program manages students waiting to register using a linked list

#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>
#include <string>

using namespace std;

class Student
{
protected:
	struct ListNode											// Struct
	{														//
		string value;										// Struct variable
		ListNode *next;										// Struct pointer to point at a type struct ListNode
		ListNode(string value1, ListNode *next1 = NULL)		// Default struct constructor
		{ value = value1; next = next1; }					//
	};														// End struct def
	ListNode *head;											// Variable
public:
	Student() { head = NULL; };								// Class default constructor
	~Student();												// Class destructor
	void addB(string value);								// Member function to add a student at the begining of list
	void add(string value);									// Member function to add a student at the end of list
	void remove(string value);								// Member function to remove a student by name
	void remove();											// Member function to remove a student from the begining of list
	void removeE();											// Member function to remove a student from the end of list
	void displayList() const;								// Member function to display the list
};
#endif
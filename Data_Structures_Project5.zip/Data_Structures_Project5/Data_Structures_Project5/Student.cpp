#include "Student.h"
#include "functions.h"

void Student::addB(string value)									// Adds a node to the begining of the list
{
	if (head == NULL)												// If head is null
		head = new ListNode(value);									// create a new ListNode as the head
	else
		head = new ListNode(value, head);							// Else head does not point to null so create a new ListNode which will be the new head that points to the old head 
	
	system("cls");													// Clear screen to to make it clean to the user
	cout << head->value << " was added successfully.\n\n" << endl;	// There should never be a problem adding a student
	system("pause");												// Pause until the user is ready to continue 
}
/*******************************************************************/
void Student::add(string value)										// Adds a node to the end of the list
{
	if (head == NULL)												// If head is null
		head = new ListNode(value);									// create a new ListNode as the head
	else
	{
		ListNode *nodePtr = head;									// Else create a ListNode and have it start at the head
		while (nodePtr->next != NULL)								// Keep running through the list until the end
			nodePtr = nodePtr->next;								// While in loop set current nodePtr to the pointer of the next Nodeptr

		nodePtr->next = new ListNode(value);						// Once at the end add the new student by creating a new ListNode
	}
	system("cls");													// Clear screen to to make it clean to the user
	cout << value << " was added successfully.\n\n" << endl;		// There should never be a problem adding a student
	system("pause");												// Pause until the user is ready to continue 
}
/*******************************************************************/
void Student::remove(string value)									// This member function removes a student from the list by name.
{
	ListNode *nodePtr, *previousNodePtr = NULL;
	string student;
	if (!head)
	{
		system("cls");
		cout << "Could not remove a student since list is empty.\n\n" << endl;
		system("pause");
		return;
	}
	if (head->value == value)										// Check head value against value and if there is a match delete it.
	{
		nodePtr = head;
		head = head->next;
		delete nodePtr;
		system("cls");
		cout << value << " was removed successfully.\n\n" << endl;
		system("pause");
	}
	else
	{
		nodePtr = head;
		
		while (nodePtr != NULL && nodePtr->value != value)			// Run through and try to locate a value match, or NULL to break out the loop 
		{
			previousNodePtr = nodePtr;
			nodePtr = nodePtr->next;
		}
		if (nodePtr)
		{
			previousNodePtr->next = nodePtr->next;
			delete nodePtr;
			system("cls");
			cout << value << " was removed successfully.\n\n" << endl;
			system("pause");
		}
		else
		{
			system("cls");
			cout << "Could not locate " << value << " in list. Please check name and try again.\n\n" << endl;
			system("pause");
		}
	}
}
/*******************************************************************/
void Student::remove()											// This member function removes a student from the begining of the list.
{
	ListNode *nodePtr, *previousNodePtr = NULL;
	string student;
	if (!head)
	{
		system("cls");
		cout << "No Students in list. The list is empty.\n\n" << endl;
		system("pause");
		return;
	}
	else
	{
		nodePtr = head;
		head = head->next;
		student = nodePtr->value;
		delete nodePtr;
		system("cls");
		cout << student << " was removed successfully.\n\n" << endl;
		system("pause");
	}
}
/*******************************************************************/
void Student::removeE()											// This member function removes a student from the end of the list.
{
	ListNode *nodePtr, *previousNodePtr = NULL;

	if (!head)
	{
		system("cls");
		cout << "No Students in list. The list is empty.\n\n" << endl;
		system("pause");
		return;
	}
	else if (head->next == NULL)
	{
		nodePtr = head;
		head = nodePtr->next;
		delete nodePtr->next;
		system("cls");
		cout << nodePtr->value << " was removed successfully.\n\n" << endl;
		system("pause");
	}
	else
	{
		nodePtr = head;
		while (nodePtr->next != NULL)
		{
			previousNodePtr = nodePtr;
			nodePtr = nodePtr->next;
		}
		if (nodePtr)
		{
			previousNodePtr->next = nodePtr->next;
			delete nodePtr->next;
			system("cls");
			cout << nodePtr->value << " was removed successfully.\n\n" << endl;
			system("pause");
		}
	}
}
/*******************************************************************/
void Student::displayList() const									// Start forward display function
{
	system("cls");
	if (!head)
		cout << "List is empty" << endl;
	else
	{
		cout << "Students in list so far." << endl;
		cout << "------------------------" << endl;
		ListNode *nodePtr = head;
		while (nodePtr)
		{
			cout << nodePtr->value << "\n";
			nodePtr = nodePtr->next;
		}
	}
	cout << "\n\n";
	system("pause");
}
/*******************************************************************/
Student::~Student()													// Deconstructor
{
	ListNode *nodePtr = head;

	while (nodePtr != NULL)
	{
		ListNode *garbage = nodePtr;
		nodePtr = nodePtr->next;
		delete garbage;
	}
}
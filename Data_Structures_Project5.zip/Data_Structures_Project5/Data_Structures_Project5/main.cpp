#include "Student.h"
#include "functions.h"

int main()
{
	bool programState = true;
	Student student;
	do
	{
		system("cls");											// Clear the console screen										
		int selection = menu();									// Selection gets the return value from called function menu

		switch (selection)										// Based on the value, choose the case that equals the value
		{
		case 1: student.addB(getCase(1));		break;			// ADD -student at the begining of list.
		case 2: student.add(getCase(1));		break;			// ADD -student at the end of the list.
		case 3: student.remove();				break;			// REMOVE -student at the begining of the list.
		case 4:	student.removeE();				break;			// REMOVE -student at the end of the list.
		case 5: student.remove(getCase(5));		break;			// REMOVE -student by name.
		case 6: student.displayList();			break;			// DISPLAY -the list of students.
		case 7: programState = false;			break;			// EXIT -the program.
		default: getCase(-1);					break;			// Handles any other input other than 1 - 7
		}														// End switch
	} while (programState);										// While this is true, keep looping through

	return 0;
}
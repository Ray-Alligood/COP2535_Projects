// Ray Alligood
// COP2535.0M1 Data Stuctures
// Project 5
// This program manages students waiting to register using a linked list

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include <string>
using namespace std;

string getCase(int);	// Handles cases passed from switch in main function 
int menu();				// Handles the menu

#endif
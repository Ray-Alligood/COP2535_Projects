// Ray Alligood
// COP2535.0M1
// Project 3 [ Compare ]
// This program will compare 2 arrays for the same elements and multiplicity.

#include <iostream>
#include <fstream>
#include <string>
#include "Compare.h"

Compare::Compare()												// The Default constructor is not setup to do much
{
	
}
/***************************************************************/
Compare::Compare(string file)									// This constructor overloads the default to take a string as an argument
{
	fileName = file;											// Sets the private variable fileName the value of file
	arrayIntalizer();											// Call the member function to intialize the array to 0
	loadData();													// Call the member function to load the data from the file
	sortArray();												// Call the member function to sort a copy array to make it easy to compare the arrays
	counter();													// Call the member function to count the number of times the value is the array
}
/***************************************************************/
void Compare::arrayIntalizer()
{
	for (int x = 0; x < SIZE; x++)								// For loop to run through and 
	{
		*(array + x) = 0;										// intialize the array to 0
		*(multiplicity + x) = 0;								// intialize the multi array to 0
	}
}
/***************************************************************/
void Compare::loadData()
{
	ifstream dataFile;											// Create a file Object																				
	int index = 0;			

	dataFile.open(fileName);									// Open the file

	if (!dataFile)												// If there is a problem opening the file
		cout << "Error opening data file\n";					// print error
	else
		while (dataFile >> *(array + index))					// Else while there is data, set current index the value
		{
			index++;											// Add 1 to index
		}
	dataFile.close();											// Don't forget to close the file
}
/***************************************************************/
void Compare::sortArray()										// This member function just uses a bubble sort
{
	int temp;															
	bool swap;	

	for (int y = 0; y < SIZE; y++)
	{
		*(arrayCpy + y) = *(array + y);							// Here and other locations in this function, I used pointer notation instead
	}

	do																	
	{
		swap = false;													
		for (int x = 0; x < SIZE - 1; x++)								
		{
			if (*(arrayCpy + x) > *(arrayCpy + (x + 1)))
			{
				temp = *(arrayCpy + x);
				*(arrayCpy + x) = *(arrayCpy + (x + 1));
				*(arrayCpy + (x + 1)) = temp;
				swap = true;																											
			}															
		}																
	} while (swap);
}
/***************************************************************/
int Compare::getValue(int index)
{
	return *(arrayCpy + index);										// Return index from which the value of the argument holds
}
/***************************************************************/
int Compare::getMultiValue(int index)
{
	return *(multiplicity + index);										// Return index from which the value of the argument holds
}
/***************************************************************/
int Compare::getSIZE()
{
	return SIZE;												// This one is kinda cool, it returns the value set for the const static int
}
/***************************************************************/
void Compare::counter()
{
	int searchVar = 0;
	int count = 1;

	for (int x = 0; x < SIZE; x++)								// Start at the first index of array
	{
		if (*(arrayCpy + x) != -1)								// This is more a flag that is in place to keep track of the numbers in the array
		{
			searchVar = *(arrayCpy + x);						// Set searchVar the value in current index
			for (int y = (x + 1); y < SIZE - 1; y++)			// This for loop runs through to search for the current value in searchVar
			{
				if (*(arrayCpy + y) == searchVar)				// If they are the same then add 1 to count
				{
					count++;									// Yeap it matched so add 1
					*(arrayCpy + y) = -1;						// So next outer loop doesn't run on this index set to -1
				}
			}
			*(multiplicity + x) = count;						// Whatever is the total count for this loop, set the current index for multiplicity that value
			count = 1;											// Reset count to 1
		}
	}
}
/***************************************************************/
void Compare::print(bool same, bool msame)
{
	if (same)																	// If the argument passed is true then
		cout << "The two arrays have same elements.\n";							// print this statement
	else
		cout << "The two arrays do not have the same elements.\n";				// Else the argument was false so print this statement

	if (msame)																	// If the argument passed is true then
		cout << "The two arrays have the same multiplicity.\n\n";				// print this statement
	else
		cout << "The two arrays do not have the same multiplicity.\n\n";		// Else the argument was false so print this statement
}
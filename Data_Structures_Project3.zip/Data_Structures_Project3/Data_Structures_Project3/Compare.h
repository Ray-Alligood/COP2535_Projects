// Ray Alligood
// COP2535.0M1
// Project 3 [ Compare ]
// This program will compare 2 arrays for the same elements and multiplicity.

#include <string>

#ifndef COMPARE_H
#define COMPARE_H

using namespace std;

class Compare
{
private:
	const static int SIZE = 6;		// Const for array size
	int array[SIZE];				// Array to holds the data from file
	int arrayCpy[SIZE];				// Array that gets the same values in array
	int multiplicity[SIZE];			// Holds the count for each value
	string fileName;				// Holds the name of the file to open

public:
	Compare();						// Default constructor
	Compare(string);				// Overloaded constructor
	void arrayIntalizer();			// Member function to intialize the array
	void loadData();				// Member function to load the data file file into the array
	void sortArray();				// Member function to sort the copied array to compare
	int getValue(int);				// Member function to return the index
	int getMultiValue(int);			// Member function to return the index for multiplicity array
	int getSIZE();					// Member function to return the value of SIZE to be used in main
	void counter();					// Member function to count the values and keep track to compare the multiplicity
	void print(bool, bool);			// Member function to accept an bool as the argument then print the statement that corrsponds to the argument
};
#endif
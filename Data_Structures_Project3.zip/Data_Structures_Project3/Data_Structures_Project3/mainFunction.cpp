// Ray Alligood
// COP2535.0M1
// Project 3 [ Compare ]
// This program will compare 2 arrays for the same elements and multiplicity.

#include "Compare.h"
#include "mainFunction.h"

bool checker(Compare *array1, Compare *array2)
{
	bool same = true;
	int count = 0;
	while (same && (count != array1->getSIZE()))
	{
		if (array1->getValue(count) != array2->getValue(count))
			same = false;
		count++;
	}
	return same;
}
/*******************************************************************/
bool multiChecker(Compare *array1, Compare *array2)
{
	bool same = true;
	int count = 0;
	while (same && (count != array1->getSIZE()))
	{
		if (array1->getMultiValue(count) != array2->getMultiValue(count))
			same = false;
		count++;
	}
	return same;
}
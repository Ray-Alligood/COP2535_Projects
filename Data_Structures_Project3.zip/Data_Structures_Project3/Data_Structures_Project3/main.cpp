// Ray Alligood
// COP2535.0M1
// Project 3 [ Compare ]
// This program will compare 2 arrays for the same elements and multiplicity.

#include <iostream>
#include <fstream>
#include <string>
#include "Compare.h"
#include "mainFunction.h"

int main()
{
	Compare *pComp1, *pComp2;														// Create 2 pointers that poin to a Compare Object
	Compare file1("comFile1.txt");													// Constructor takes a string as an argument which is the name of the first file of numbers
	Compare file2("comFile2.txt");													// Constructor takes a string as an argument which is the name of the second file of numbers

	pComp1 = &file1;																// Store the address of file1 in pComp1
	pComp2 = &file2;																// Store the address of file2 in pComp2

	pComp1->print(checker(pComp1, pComp2), multiChecker(pComp1, pComp2));			// Call the member function with the return argument of the function to compare the objects

	return 0;
}
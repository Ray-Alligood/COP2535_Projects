// Ray Alligood
// COP2535.0M1
// Project 3 [ Compare ]
// This program will compare 2 arrays for the same elements and multiplicity.

bool checker(Compare *pComp1, Compare *pComp2);							// Function prototype to compare the 2 objects
bool multiChecker(Compare *pComp1, Compare *pComp2);					// Function prototype to compare the multiplicity
// Ray Alligood
// COP2535.0M1
// Project 4 [ Accumulation ]
// This program uses a template function to sum values of integers and strings

#include "Accumulation.h"

int main()
{	
	Accumulation myAccum;		// Create an object

	return 0;
}
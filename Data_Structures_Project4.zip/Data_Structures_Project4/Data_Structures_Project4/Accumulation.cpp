// Ray Alligood
// COP2535.0M1
// Project 4 [ Accumulation ]
// This program uses a template function to sum values of integers and strings

#include "Accumulation.h"

Accumulation::Accumulation()
{
	loadFile();													// Call member function to load the file
}
/***************************************************************/
void Accumulation::loadFile()
{
	int myint = 0;												// Holds the current integer from file
	string mystr = "";											// Holds the current string from file
	ifstream dataFile;											// Create an Object
	vector<int> intVect;										// Create a vector of integers to be passed to sum
	vector<string> strVect;										// Create a vector of strings to be passed to sum

	dataFile.open("tempData.txt");								// Open the file

	if (!dataFile)												// If there is a problem opening the file
		cout << "Error opening data file\n";					// print error
	else
	{
		while (dataFile)										// While dataFile is true
		{
			try													// Try the following block of code
			{
				if (dataFile >> myint)							// If current read is an integer
					intVect.push_back(myint);					// Then add that value to the vector
				else											// Else
					throw string(mystr);						// Throw a string exception
			}													// End try
			catch (string mystr)								// Catch the string exception 
			{
				dataFile.clear();								// Clear for a good read							
				if (dataFile >> mystr)							// If it's a data type string					
					strVect.push_back(mystr);					// then add the value into the vector
			}													// End catch
		}														// End while loop
	cout << "  Sum: " << accum(intVect) << endl;				// Call member function passing the vector type integers
	cout << "  Sum: " << accum(strVect) << endl;				// Call member function passing the vector type strings
	cout << "\n\n";
		dataFile.close();										// Close the file
	}
}
/***************************************************************/
template <class T> T Accumulation::accum(vector<T> v)
{
	int SIZE = v.size();										// Get the size of the vector
	int x, y = 0;

	for (x = 1; x < SIZE; x++)									// Set x to 1, since index 0 is going to be used to sum all the values
	{															// In doing so, it created a problem printing out the values
		cout << v[x - 1] << " ";								// Print x - 1 which is what y is, so it will not print the last value which is handled below
		v[y] = v[y] + v[x];										// Sum the values starting with index y, which y does not change from index 0
	}
	x = SIZE -1;												// Assign x to SIZE - 1, which is needed to print the last value
	cout << v[x];												// Now print the last value
	return v[y];												// Return the sum of v[y]
}
/***************************************************************/
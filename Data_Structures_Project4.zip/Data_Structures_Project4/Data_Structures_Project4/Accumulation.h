// Ray Alligood
// COP2535.0M1
// Project 4 [ Accumulation ]
// This program uses a template function to sum values of integers and strings

#ifndef ACCUMULATION_H
#define ACCUMULATION_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

class Accumulation
{
private:

public:
	Accumulation();									// Default constructor
	void loadFile();								// Member function to load the file
	template <class T> T accum(vector<T>);			// Member function to sum different data types
};

#endif